let word;

function setupWord(element, initWord) {}

function isLetterInWord(letter) {}

function revealLetterInWord(letter) {}
